import { useContext, useState } from "react";
import { AuthContext } from "../../context/AuthContext";
import { UserActions } from "./components/UserActions/UserActions";
import { Orders } from "./components/Orders/Orders";
import { Modal } from "./components/Modal/Modal";
import "./Cart.css";
import axios from 'axios'; 

export const Cart = () => {
  // Asegúrate de traer `setCartItems` desde el AuthContext
  const { cartItems, removeFromCart, user, setCartItems } = useContext(AuthContext); 
  const [view, setView] = useState("cart");
  const [isModalOpen, setModalOpen] = useState(false);

  const handlePaymentSubmit = async (shippingAddress, postalCode, city, paymentMethod) => {
    if (!user) {
      console.error("Usuario no autenticado.");
      return;
    }

    try {
      const response = await axios.post("http://localhost:5000/create-order", {
        user_id: user.id,
        shippingAddress,
        postalCode,
        city,
        paymentMethod,
        cartItems,
      });

      if (response.status === 200 && response.data.orderId) {
        console.log("Pedido procesado con éxito:", response.data);
        setModalOpen(false);
        // Vaciar el carrito en el frontend
        setCartItems([]); // Vacía el carrito en el estado
        localStorage.removeItem("cart"); // Vacía el carrito también en localStorage
        
        // Mostrar modal de éxito o alerta
        alert("Pedido procesado exitosamente");
      } else {
        console.error('Error al procesar el pedido:', response.data);
      }
    } catch (error) {
      console.error('Error en la solicitud:', error);
    }
  };
  
  const renderCartItems = () => (
    <>
      <h2>Carrito de Compras</h2>
      {cartItems.length > 0 ? (
        <>
          <ul>
            {cartItems.map((item, index) => (
              <li key={index} className="cart-item">
                <img
                  src={item.pack_image}
                  alt={item.pack_title}
                  className="cart-item-image"
                />
                <div className="cart-item-details">
                  <h3>{item.pack_title}</h3>
                  <p>{item.pack_price} €</p>
                  <p>Destino: {item.pack_destination}</p>
                </div>
                <button
                  onClick={() => removeFromCart(index)}
                  className="remove-button"
                >
                  Eliminar del Carrito
                </button>
              </li>
            ))}
          </ul>

          <div className="cart-total-section">
            <h3>
              Total:{" "}
              {cartItems
                .reduce((total, item) => total + item.pack_price, 0)
                .toFixed(2)}{" "}
              €
            </h3>
            <button
              className="checkout-button"
              onClick={() => setModalOpen(true)}
            >
              Finalizar y Procesar Pago
            </button>
          </div>
        </>
      ) : (
        <p>El carrito está vacío.</p>
      )}
    </>
  );

  return (
    <div className="cart-page">
      <div className="user-actions">
        <UserActions setView={setView} />
      </div>
      <div className="cart-content">
        {view === "cart" && renderCartItems()}
        {view === "orders" && <Orders />}
      </div>

      {/* Modal para finalizar la compra */}
      <Modal
        isOpen={isModalOpen}
        closeModal={() => setModalOpen(false)}
        handleSubmit={handlePaymentSubmit}
      />

    </div>
  );
};
