import { useContext, useEffect, useState } from "react";
import { AuthContext } from "../../../../context/AuthContext";
import axios from "axios";
import "./Orders.css"; // Importa el archivo CSS

export const Orders = () => {
  const { user } = useContext(AuthContext);
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/orders/${user.id}`);
        
        // Agrupar los pedidos por `order_id`
        const groupedOrders = response.data.reduce((acc, item) => {
          const { order_id, order_date, status } = item;

          if (!acc[order_id]) {
            acc[order_id] = {
              order_id,
              order_date,
              status,
              items: [],
            };
          }
          acc[order_id].items.push(item); // Agregar el item al pedido correspondiente
          return acc;
        }, {});

        // Convertir el objeto agrupado en un array de pedidos
        setOrders(Object.values(groupedOrders));
      } catch (error) {
        console.error("Error al obtener el historial de pedidos:", error);
      }
    };

    if (user) {
      fetchOrders();
    }
  }, [user]);

  const handleDeleteOrder = async (orderId) => {
    const confirmed = window.confirm("¿Estás seguro de que deseas eliminar este pedido?");
    
    if (confirmed) {
      try {
        const response = await axios.delete(`http://localhost:5000/delete-orders/${orderId}`);
        if (response.status === 200) {
          setOrders(orders.filter(order => order.order_id !== orderId));
          alert("Pedido eliminado con éxito.");
        } else {
          alert("Hubo un problema al eliminar el pedido.");
        }
      } catch (error) {
        console.error("Error al eliminar el pedido:", error);
        alert("Error al eliminar el pedido.");
      }
    }
  };

  if (orders.length === 0) {
    return <p className="orders-empty">No tienes pedidos en tu historial.</p>;
  }

  return (
    <div className="orders-container">
      <h2>Historial de Pedidos</h2>
      
      {orders.map((order) => (
        <div key={order.order_id} className="order-card">
          <div className="order-card-details">
            <div className="order-card-title-row">
                <h3>Pedido #{order.order_id}</h3>
                <button className="delete-order-btn" onClick={() => handleDeleteOrder(order.order_id)}>
                    ❌ 
                </button>
            </div>

                
                <p className="order-date">Fecha: {new Date(order.order_date).toLocaleDateString()}</p>
                <p className="order-status">Estado: {order.status === 0 ? "Pendiente" : "Procesado"}</p>
          </div>

          {/* Mostrar los items asociados al pedido */}

          <div className="order-items">
            {order.items.map((item) => (
              <div key={item.order_item_id} className="order-item">
                <p>Paquete: {item.pack_title}</p>
                <p>Precio: {item.pack_price} €</p>
                <p>Cantidad: {item.quantity}</p>
              </div>
            ))}
          </div>

          {/* Botón para eliminar pedido */}

        </div>
      ))}
    </div>
  );
};
