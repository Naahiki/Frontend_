import PropTypes from "prop-types";
import "./UserActions.css";

export const UserActions = ({ setView }) => {
  return (
    <div className="user-actions-container">
      <h3>Acciones de Usuario</h3>
      <button onClick={() => setView("cart")}>Ver Carrito</button>
      <button onClick={() => setView("orders")}>Ver Historial de Pedidos</button>
      {/* Aquí puedes añadir más acciones si las necesitas */}
    </div>
  );
};

UserActions.propTypes = {
  setView: PropTypes.func.isRequired,
};
